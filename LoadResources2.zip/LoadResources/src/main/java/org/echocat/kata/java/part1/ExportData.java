package org.echocat.kata.java.part1;

import org.echocat.kata.java.model.Author;
import org.echocat.kata.java.model.Book;
import org.echocat.kata.java.model.Document;
import org.echocat.kata.java.model.Magazine;
import org.echocat.kata.java.service.RequiredServices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class ExportData {

    // Drivers Method
    public static void main(String[] args) {

//       1 - Your software should read all data from the given CSV files in a meaningful structure.
//       2 - Print out all books and magazines (could be a GUI, console, …) with all their details (with a meaningful output format).
//        Hint: Do not call printBooks(...) first and then printMagazines(...) ;-)

        System.out.println("2 - Print out all books and magazines (could be a GUI, console, …) with all their details");
        List<Document> documents = RequiredServices.collectThemAll();

        for (Document document : documents) {
            System.out.println(document);
        }

//       3 - Find a book or magazine by its isbn
        System.out.println("3 - Find a book or magazine by its isbn:");
        List<Document> filterDocuments;

        filterDocuments = documents
                .stream()
                .filter(b -> b.getIsbn().equals("2145-8548-3325"))
                .collect(Collectors.toList());
        System.out.println(filterDocuments);

        // 4 -  Find all books and magazines by their authors’ email.
        System.out.println("4 -  Find all books and magazines by their authors’ email.");

        filterDocuments = documents
                .stream()
                .filter(b -> b.getAuthors().contains("null-walter@echocat.org"))
                .collect(Collectors.toList());
        System.out.println(filterDocuments);

        // 5 -  Print out all books and magazines with all their details sorted by title. This sort should be done for books and magazines together.

        System.out.println("5 -  Print out all books and magazines with all their details sorted by title.");

        filterDocuments = documents.stream().sorted((o1, o2) -> o1.getTitle().
                compareTo(o2.getTitle())).collect(Collectors.toList());
        for (Document document : filterDocuments) {
            System.out.println(document);
        }

    }
}
