package org.echocat.kata.java.model;

import java.util.Date;

public class Magazine extends Document {

    private Date publishedAt;

    public Date getPublishedAt() {
        return publishedAt;
    }

    public void setPublishedAt(Date publishedAt) {
        this.publishedAt = publishedAt;
    }

    public Magazine(String title, String isbn, String authors, Date publishedAt) {
        super(title, isbn, authors);
        this.publishedAt = publishedAt;
    }

    @Override
    public String toString() {
        return "Magazine [title=" + getTitle() + ", isbn=" + getIsbn() + ", authors=" + getAuthors() + ", publishedAt=" + publishedAt + "]";
    }
}
