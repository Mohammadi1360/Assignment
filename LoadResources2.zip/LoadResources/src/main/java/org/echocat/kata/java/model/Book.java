package org.echocat.kata.java.model;

public class Book extends Document {
    private String description;


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Book(String title, String isbn, String authors, String description) {
        super(title, isbn, authors);
        this.description = description;
    }

    @Override
    public String toString() {
        return "Book [title=" + getTitle() + ", isbn=" + getIsbn() + ", authors=" + getAuthors() + ", description=" + description + "]";
    }
}
