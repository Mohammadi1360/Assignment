package org.echocat.kata.java.service;

import org.echocat.kata.java.converter.ReadFromAuthorFile;
import org.echocat.kata.java.converter.ReadFromDocumentFile;

import org.echocat.kata.java.model.Author;
import org.echocat.kata.java.model.Document;

import java.util.ArrayList;
import java.util.List;

public class RequiredServices {
    public static List<Document> documents;

    public static List<Document> collectThemAll() {
        List<Document> books = ReadFromDocumentFile.readFromCSV("books.csv", true, "Book");
        List<Document> magazines = ReadFromDocumentFile.readFromCSV("magazines.csv", true, "Magazine");
        List<Author> authors = ReadFromAuthorFile.readFromCSV("authors.csv", true, "");

        documents = new ArrayList<>(books);
        documents.addAll(magazines);
        return documents;
    }


}



