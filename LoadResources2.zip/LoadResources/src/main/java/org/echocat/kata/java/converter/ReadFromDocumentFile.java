package org.echocat.kata.java.converter;

import org.echocat.kata.java.model.Book;
import org.echocat.kata.java.model.Document;
import org.echocat.kata.java.model.Magazine;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class ReadFromDocumentFile {

    public static List<Document> readFromCSV(String fileName, boolean breakHeader, String documentType) {
        List<Document> documents = new ArrayList<>();

        try {
            Resource resource = new ClassPathResource(fileName);
            File file = resource.getFile();

            Scanner reader = new Scanner(file);
            String row = "";

            BufferedReader csvReader = new BufferedReader(new FileReader(file));
            int i = 0;

            while ((row = csvReader.readLine()) != null) {
                if (breakHeader && i == 0) {
                    i++;
                    continue;
                }
                String[] metadata = row.split(";");
                Document document = createIt(metadata, documentType);
                documents.add(document);
                i++;
            }
            csvReader.close();
            reader.close();
        } catch (FileNotFoundException e) {
            System.out.println("File reading error occurred.");
            e.printStackTrace();
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        return documents;
    }

    //use getShape method to get object of type shape
    static Document createIt(String[] metadata, String documentType) throws ParseException {
        if (documentType == null) {
            return null;
        }
        if (documentType.equalsIgnoreCase("Book")) {
            return new Book(metadata[0], metadata[1], metadata[2], metadata[3]);

        } else if (documentType.equalsIgnoreCase("Magazine")) {
            Date publishedAt = new SimpleDateFormat("dd.MM.yyyy").parse(metadata[3]);
            return new Magazine(metadata[0], metadata[1], metadata[2], publishedAt);
        }

        return null;
    }

}
