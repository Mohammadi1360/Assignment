package org.echocat.kata.java.part1;

import org.echocat.kata.java.model.Document;
import org.echocat.kata.java.service.RequiredServices;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
public class ExportDataTest {

    @Test
    public void checkAnagramTest() throws Exception {
        List<Document> documents = RequiredServices.collectThemAll();
        Assert.assertEquals(documents.size(), 14);
    }

}
