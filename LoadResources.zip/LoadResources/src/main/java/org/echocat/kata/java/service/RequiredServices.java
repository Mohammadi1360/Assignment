package org.echocat.kata.java.service;

import org.echocat.kata.java.converter.ReadAuthorsFromFile;
import org.echocat.kata.java.converter.ReadBooksFromFile;
import org.echocat.kata.java.converter.ReadMagazinesFromFile;
import org.echocat.kata.java.model.Author;
import org.echocat.kata.java.model.Book;
import org.echocat.kata.java.model.Document;
import org.echocat.kata.java.model.Magazine;

import java.util.ArrayList;
import java.util.List;

public class RequiredServices {
    public static List<Document> documents;

    public static List<Document> collectThemAll() {
        List<Book> books = ReadBooksFromFile.readBooksFromCSV("books.csv", true);
        List<Author> authors = ReadAuthorsFromFile.readAuthorsFromCSV("authors.csv", true);
        List<Magazine> magazines = ReadMagazinesFromFile.readMagazinesFromCSV("magazines.csv", true);

        documents = new ArrayList<>(books);
        documents.addAll(magazines);
        return documents;
    }




}



