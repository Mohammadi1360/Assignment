package org.echocat.kata.java.converter;

import org.echocat.kata.java.model.Magazine;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class ReadMagazinesFromFile {

    public static List<Magazine> readMagazinesFromCSV(String fileName, boolean breakHeader) {
        List<Magazine> Magazines = new ArrayList<>();

        try {
            Resource resource = new ClassPathResource(fileName);
            File file = resource.getFile();

            Scanner reader = new Scanner(file);
            String row = "";

            BufferedReader csvReader = new BufferedReader(new FileReader(file));
            int i = 0;

            while ((row = csvReader.readLine()) != null) {
                if (breakHeader && i == 0) {
                    i++;
                    continue;
                }
                String[] metadata = row.split(";");
                Magazine Magazine = createMagazine(metadata);
                Magazines.add(Magazine);
                i++;
            }
            csvReader.close();
            reader.close();
        } catch (FileNotFoundException e) {
            System.out.println("File reading error occurred.");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return Magazines;
    }

    private static Magazine createMagazine(String[] metadata) throws ParseException {
        String title = metadata[0];
        String isbn = metadata[1];
        String authors = metadata[2];
        Date publishedAt=new SimpleDateFormat("dd.MM.yyyy").parse(metadata[3]);

        // create and return Magazine of this metadata
        return new Magazine(title, isbn, authors, publishedAt);
    }
}
