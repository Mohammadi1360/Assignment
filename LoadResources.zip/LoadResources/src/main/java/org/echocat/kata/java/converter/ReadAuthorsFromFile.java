package org.echocat.kata.java.converter;

import org.echocat.kata.java.model.Author;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ReadAuthorsFromFile {

    public static List<Author> readAuthorsFromCSV(String fileName, boolean breakHeader) {
        List<Author> Authors = new ArrayList<>();

        try {
            Resource resource = new ClassPathResource(fileName);
            File file = resource.getFile();

            Scanner reader = new Scanner(file);
            String row = "";

            BufferedReader csvReader = new BufferedReader(new FileReader(file));
            int i = 0;

            while ((row = csvReader.readLine()) != null) {
                if (breakHeader && i == 0) {
                    i++;
                    continue;
                }
                String[] metadata = row.split(";");
                Author Author = createAuthor(metadata);
                Authors.add(Author);
                i++;
            }
            csvReader.close();
            reader.close();
        } catch (FileNotFoundException e) {
            System.out.println("File reading error occurred.");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return Authors;
    }

    private static Author createAuthor(String[] metadata) {
        String email = metadata[0];
        String firstName = metadata[1];
        String lastName = metadata[2];

        // create and return Author of this metadata
        return new Author(email, firstName, lastName);
    }
}
