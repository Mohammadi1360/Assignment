package org.echocat.kata.java.converter;

import org.echocat.kata.java.model.Book;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ReadBooksFromFile {

    public static List<Book> readBooksFromCSV(String fileName, boolean breakHeader) {
        List<Book> books = new ArrayList<>();

        try {
            Resource resource = new ClassPathResource(fileName);
            File file = resource.getFile();

            Scanner reader = new Scanner(file);
            String row = "";

            BufferedReader csvReader = new BufferedReader(new FileReader(file));
            int i = 0;

            while ((row = csvReader.readLine()) != null) {
                if (breakHeader && i == 0) {
                    i++;
                    continue;
                }
                String[] metadata = row.split(";");
                Book book = createBook(metadata);
                books.add(book);
                i++;
            }
            csvReader.close();
            reader.close();
        } catch (FileNotFoundException e) {
            System.out.println("File reading error occurred.");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return books;
    }

    private static Book createBook(String[] metadata) {
        String title = metadata[0];
        String isbn = metadata[1];
        String authors = metadata[2];
        String description = metadata[3];

        // create and return book of this metadata
        return new Book(title, isbn, authors, description);
    }
}
