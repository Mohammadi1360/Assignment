package com.anagrams.anagramfetch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnagramFetchApplicationTests {

	@Test
	void contextLoads() {
	}

}
