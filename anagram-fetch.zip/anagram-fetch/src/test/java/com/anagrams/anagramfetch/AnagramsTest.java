package com.anagrams.anagramfetch;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
//@SpringBootTest(classes = AnagramFetchApplication.class)
public class AnagramsTest {

    @Test
    public void checkAnagramTest() throws Exception {
        ArrayList<String> inputList = new ArrayList<>();
        inputList.add("hi");
        inputList.add("ho");
        inputList.add("ih");
        inputList.add("oh");
        inputList.add("th");

        Assert.assertEquals(Anagrams.checkAnagram(inputList).toString(),"[[hi], [ho], [th]]");

    }


}
