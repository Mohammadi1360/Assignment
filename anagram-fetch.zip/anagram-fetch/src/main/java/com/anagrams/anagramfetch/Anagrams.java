package com.anagrams.anagramfetch;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;

public class Anagrams {

    public static ArrayList<ArrayList<String>> checkAnagram(ArrayList<String> inputList) {
        HashMap<HashMap<Character, Integer>, ArrayList<String>> finalMap = new HashMap<HashMap<Character, Integer>, ArrayList<String>>();
        for (String indexString : inputList) {
            HashMap<Character, Integer> tmpMap = new HashMap<Character, Integer>();

            for (int i = 0; i < indexString.length(); i++) {
                if (tmpMap.containsKey(indexString.charAt(i))) {
                    int x = tmpMap.get(indexString.charAt(i));
                    tmpMap.put(indexString.charAt(i), ++x);
                } else {
                    tmpMap.put(indexString.charAt(i), 1);
                }
            }

            if (!finalMap.containsKey(tmpMap)){
                ArrayList<String>
                        tempList = new ArrayList<String>();
                tempList.add(indexString);
                finalMap.put(tmpMap, tempList);
            }
        }

        ArrayList<ArrayList<String>>
                myResult = new ArrayList<>();
        for (HashMap<Character, Integer>
                temp : finalMap.keySet())
            myResult.add(finalMap.get(temp));

        return myResult;
    }

    // Drivers Method
    public static void main(String[] args) {
        ArrayList<String> words = new ArrayList<>();
        try {
            Resource resource = new ClassPathResource("words.txt");
            File file = resource.getFile();

            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()) {
                String word = reader.nextLine();
                words.add(word);
//                System.out.println(word);
            }
            reader.close();
        } catch (FileNotFoundException e) {
            System.out.println("File reading error occurred.");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        System.out.println(dateFormat.format(new Date()));
        System.out.println(checkAnagram(words));
        System.out.println(dateFormat.format(new Date()));

    }
}
