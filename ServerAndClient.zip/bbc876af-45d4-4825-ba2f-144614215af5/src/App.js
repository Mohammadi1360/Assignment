import React, {Component} from 'react';
import './App.css';
import 'h8k-components';
import ProductList from "./components/product-list";
import Cart from "./components/cart";

const title = "HackerShop";

class App extends Component {
    constructor() {
        super();
        let products = [...PRODUCTS].map((product, index) => {
            product.id = index + 1;
            product.image = `/images/items/${product.name.toLocaleLowerCase()}.png`;
            product.cartQuantity = 0;
            return product;
        });
        this.state = {
            cart: {
                items: []
            },
            products
        }
    }

    handlePlus = (index) => {
        let newProducts = this.state.products.slice();
        newProducts[index].cartQuantity = newProducts[index].cartQuantity + 1;

        this.setState({
            products: [...newProducts]
        });
    }

    handleReduce = (index) => {
        let newProducts = this.state.products.slice();
        if (newProducts[index].cartQuantity > 0) {
            newProducts[index].cartQuantity = newProducts[index].cartQuantity - 1;
        }

        this.setState({
            products: [...newProducts]
        });
    }

    handleAddItem = (index) => {
        let newProducts = this.state.products.slice();

        if (newProducts[index].cartQuantity > 0) {
            let item = Object.create(newProducts[index]);
            item.quantity = newProducts[index].cartQuantity;
            newProducts[index].cartQuantity = 0;

            this.setState({
                cart: {
                    items: [...this.state.cart.items,item]
                },
                products: [...newProducts]
            });
        }
    }


    render() {
        return (
            <div>
                <h8k-navbar header={title}></h8k-navbar>
                <div className="layout-row shop-component">
                    <ProductList products={this.state.products}
                                 handlePlus={this.handlePlus}
                                 handleReduce={this.handleReduce}
                                 handleAddItem={this.handleAddItem}/>

                    <Cart cart={this.state.cart}/>
                </div>
            </div>
        );
    }
}

export const PRODUCTS = [
    {
        name: "Cap",
        price: 5
    },
    {
        name: "HandBag",
        price: 30
    },
    {
        name: "Shirt",
        price: 35
    },
    {
        name: "Shoe",
        price: 50
    },
    {
        name: "Pant",
        price: 35
    },
    {
        name: "Slipper",
        price: 25
    }
];
export default App;
